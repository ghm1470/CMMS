import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assigned-part-action',
  templateUrl: './assigned-part-action.component.html',
  styleUrls: ['./assigned-part-action.component.scss']
})
export class AssignedPartActionComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
