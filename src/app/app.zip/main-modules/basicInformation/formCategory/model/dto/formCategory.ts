export class FormCategory {
  id: string;
  title: string;
}
