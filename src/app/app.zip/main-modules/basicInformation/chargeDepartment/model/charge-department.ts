export class ChargeDepartment {
  id: string;
  title: string;
  code: string;
  description: string;
  // abilities: string[];
}

