export class UnitOfMeasurement {
  measurementRange: string;
  nominalAccuracy: string;
  organId: string;
  type: string;
  id: string;
  title: string;
  unit: string;


}
