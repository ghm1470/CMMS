export enum WorkOrderStatusEnum {
  DRAFT = 'پیش نویس' as any,
  PENDING = 'انتظار' as any,
  CLOSED = 'بسته' as any,
  OPENED = 'در حال انجام کار' as any,
  // ACTIVE = <any> 'فعال',
  // CLOSEDINCOMPLETE = <any> 'بسته ناقص',
  // CLOSEDCOMPLETE = <any> 'بسته کامل',
  // OPENED = <any> 'در حال انجام کار',
  // REQUESTED = <any> 'درخواست شده'
}
