import {WorkOrderStatusEnum} from '../helper/workOrderStatusEnum';

export class WorkOrderStatus {
  id: string;
  name: string;
  status: WorkOrderStatusEnum;
}
