export class Currency {
  id: string;
  title: string;
  isoCode: string;
  organId: string;
}
