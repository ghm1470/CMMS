export namespace PropertyCategoryDto {
  export class Create {
    id: string;
    title: string;
    code: string;
  }
}
