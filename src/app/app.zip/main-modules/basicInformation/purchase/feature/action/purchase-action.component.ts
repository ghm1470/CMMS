import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-action',
  templateUrl: './purchase-action.component.html',
  styleUrls: ['./purchase-action.component.scss']
})
export class PurchaseActionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
