export class Post {
  id: string;
  title: string;
  organizationId: string;

  firstStep: boolean;
  secondStep: boolean;
  thirdStep: boolean;
  fourthStep: boolean;
  fifthStep: boolean;
  sixthStep: boolean;
}
