export class WorkOrderAccess {
   userId: string;
   activityId: string;
   code = false;
   title = false;
   requiredCompletionDate = false;
   image = false;
   assetId = false;
   projectId = false;
   startDate = false;
   endDate = false;
   statusId = false;
   priority = false;
   maintenanceType = false;
   workOrderAccessId: string;
}





