
export class Organization {
  id: string;
  title: string;
  parkId: string;
}
