export class GetEmployeeFilter {
  firstName = '';
  lastName = '';
  phone = '';
  employeeCode = '';
  postId: string = null;
  parkId: string;
}
