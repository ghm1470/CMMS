export enum ActionType {
  ACTION_ACCEPT = <any> 'ACTION_ACCEPT',
  ACTION_REJECTION = <any> 'ACTION_REJECTION', // رد
  ACTION_CORRECTION = <any> 'ACTION_CORRECTION', // اصلاح
  REQUEST = <any> 'REQUEST',
  CANCEL = <any> 'CANCEL',
}
