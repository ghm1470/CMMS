import {Component, OnDestroy, OnInit} from '@angular/core';
import {Activity} from '../../model/activity';
import {ActivityService} from '../../service/activity.service';
import {ActionMode, DefaultNotify, Paging} from '@angular-boot/util';
import {ActivatedRoute, Router} from '@angular/router';
import {CacheService, CacheType, takeUntilDestroyed} from '@angular-boot/core';
import {TokenRoleList} from '../../../../shared/shared/constants/tokenRoleList';
import {Auth} from '../../../../shared/constants/cacheKeys';
import {ModalUtil} from '@angular-boot/widgets';
import {DeleteModel} from '../../../../shared/conferm-delete/model/delete-model';
import {Tools} from "../../../../shared/tools/Tools";
import {NotiConfig} from "../../../../shared/tools/notifyConfig";

@Component({
    selector: 'app-activity-list',
    templateUrl: './activity-list.component.html',
    styleUrls: ['./activity-list.component.scss']
})
export class ActivityListComponent implements OnInit, OnDestroy {


///////////////////////////////
    pageSize = 10;
    pageIndex = 0;
    length = -1;
    term: string;

    entityList: Activity[] = [];
    loading: boolean;

    selectedItemForDelete = new DeleteModel();

    roleList = new TokenRoleList();
    tools = Tools;

    constructor(private entityService: ActivityService,
                public router: Router,
                private cacheService: CacheService,
                private activatedRoute: ActivatedRoute) {
        this.activatedRoute.queryParams.subscribe(params => {
            params.pageIndex ? this.pageIndex = params.pageIndex : '';
            params.pageSize ? this.pageSize = params.pageSize : '';
            params.term ? this.term = params.term : '';
            this.getPage();

        });
    }

    ngOnInit() {
        this.getRoleListKey();
    }


    getRoleListKey() {
        this.cacheService.getItem(Auth.RoleListKey,
            CacheType.LOCAL_STORAGE).pipe(takeUntilDestroyed(this)).subscribe((res: any) => {
            if (res) {
                this.roleList = res;
            }
        });
    }

    getPage() {
        this.loading = true;
        const paging = new Paging();
        paging.page = this.pageIndex;
        paging.size = this.pageSize;

        this.entityService.getAllByPagination({
            paging,
            totalElements:-1,
            term: this.term
        })
            // this.entityService.getAll()
            .subscribe((res: any) => {
                if (res) {
                    this.entityList = res.content;
                    this.length = res.totalElements;
                    this.loading = false;
                }
                ;
            }, error => {
                this.loading = false;
            });
    }

    search() {
        if (this.pageIndex == 0) {
            this.getPage();
        } else {
            this.pageIndex = 0;
            this.navigate();
        }

    }

    navigate() {
        this.router.navigate([window.location.hash.split('#/')[1].split('?')[0]], {
            queryParams: {
                pageIndex: this.pageIndex,
                pageSize: this.pageSize,
                term: this.term,
            },
        });

    }

    changePage(event: any) {
        this.length = event.length;
        this.pageIndex = event.pageIndex;
        this.pageSize = event.pageSize;
        this.navigate();

    }

    loadingChooseSelectedItemForEdit = false;
    loadingChooseSelectedItemForDelete = false;
    SelectedItemForEditId: string;

    chooseSelectedItemForEdit(item: Activity) {
        if (this.loadingChooseSelectedItemForEdit) {
            return;
        }
        this.loadingChooseSelectedItemForEdit = true;
        this.SelectedItemForEditId = item.id;
        this.entityService.checkIfActivityIsInProcess({
            activityId: item.id
        }).pipe(takeUntilDestroyed(this)).subscribe((res: boolean) => {
            this.loadingChooseSelectedItemForEdit = false;
            if (!res) {
                this.router.navigate(['/panel/activity/edit', item.id], {
                    // queryParams: {mode: ActionMode.EDIT, categoryId: item.id},
                    relativeTo: this.activatedRoute
                });
            } else if (res) {
                DefaultNotify.notifyDanger('از این فرایند درحال حاضر استفاده می شود.', '', NotiConfig.notifyConfig);
            }
        }, error => {
            this.loadingChooseSelectedItemForEdit = false;
        });
    }


    showModalDelete(item: Activity, i) {
        this.loadingChooseSelectedItemForDelete = true;
        this.SelectedItemForEditId = item.id;
        this.entityService.checkIfActivityExistsInAssetOrActivity({
            activityId: item.id
        }).pipe(takeUntilDestroyed(this)).subscribe((res: any) => {
            this.loadingChooseSelectedItemForDelete = false;
            if (!res.exist) {
                this.selectedItemForDelete.loading = false;

                this.selectedItemForDelete.id = item.id;
                this.selectedItemForDelete.title = ' آیا    ' + item.title + ' حذف  شود؟ ';
                this.selectedItemForDelete.index = i;
                setTimeout(e => {
                    ModalUtil.showModal('modalId' + this.selectedItemForDelete.id);
                }, 10);
            } else if (res.exist) {
                DefaultNotify.notifyDanger(res.description + '.', '', NotiConfig.notifyConfig);
            }
        }, error => {
            this.loadingChooseSelectedItemForDelete = false;
        });


    }

    deleteItem(event) {
        if (event) {
            this.selectedItemForDelete.loading = true;
            this.entityService.delete({activityId: this.selectedItemForDelete.id})
                .pipe(takeUntilDestroyed(this)).subscribe((res) => {
                this.selectedItemForDelete.loading = false;
                if (res === true) {
                    this.entityList.splice(this.selectedItemForDelete.index, 1);
                    ModalUtil.hideModal('modalId' + this.selectedItemForDelete.id);
                    if (this.entityList.length === 0) {
                        this.pageIndex = this.pageIndex - 1;
                        if (this.pageIndex < 0) {
                            this.pageIndex = 0;
                            this.getPage();
                        }
                        this.navigate();
                    }
                } else {
                    DefaultNotify.notifyDanger(res, '', NotiConfig.notifyConfig);
                    ModalUtil.hideModal('modalId' + this.selectedItemForDelete.id);
                }
            });


        } else {
            ModalUtil.hideModal('modalId' + this.selectedItemForDelete.id);
        }
    }

    ngOnDestroy(): void {
    }


    //////////////////////////////////////
}


//   componentData: ComponentData;
//   totalElements = 0;
//   loading: boolean;
//   roleList = new TokenRoleList();
//   dataOfActivityList: Activity [] = [];
//   selectedItemForDelete = new DeleteModel();
//   totalPages = 0;
//   tools = Tools;
//
//   constructor(
//     protected _Router: Router,
//     protected _ActivatedRoute: ActivatedRoute,
//     private activityService: ActivityService,
//     private cacheService: CacheService) {
//     super(_ActivatedRoute, _Router, CourseParam.RouteParam, CourseParam.QueryParam);
//     this.componentData = new ComponentData();
//     this.receiveData();
//   }
//
//   canDeactivate(): boolean {
//     return true;
//   }
//
//   ngOnInit() {
//     this.getRoleListKey();
//   }
//
//   onReceiveRouteParam(routeParam: CourseParam.RouteParam) {
//   }
//
//   onReceiveQueryParam(queryParam: CourseParam.QueryParam) {
//     this.componentData.myQuery = queryParam;
//     this.loading = true;
//     this.getActivityList();
//   }
//
//   onReceiveRouteData(routeData: any) {
//   }
//
//   getRoleListKey() {
//     this.cacheService.getItem(Auth.RoleListKey, CacheType.LOCAL_STORAGE).pipe(takeUntilDestroyed(this)).subscribe((res: any) => {
//       if (res) {
//         this.roleList = res;
//       }
//     });
//   }
//
//   getActivityList() {
//     this.dataOfActivityList = [];
//     this.activityService.getAllByPagination({
//       paging: this.componentData.myQuery.paging,
//       totalElements: this.totalElements,
//       term: this.componentData.myQuery.term
//     }).pipe(takeUntilDestroyed(this)).subscribe((res: PageContainer<Activity>) => {
//       this.loading = false;
//       ;
//       this.dataOfActivityList = res.content;
//       this.totalElements = res.totalElements;
//       this.totalPages = res.totalPages;
//     });
//   }
//
//   setPage(page) {
//     super.setToQueryParams({page: page, size: this.componentData.myQuery.paging.size});
//   }
//
//
//   search() {
//     this.totalElements = 0;
//     super.setToQueryParams({
//       page: 0,
//       size: 10,
//       term: this.componentData.myQuery.term
//     });
//   }
//
//   showModalDelete(item, i) {
//     this.selectedItemForDelete.loading = false;
//     this.selectedItemForDelete.id = item.id;
//     this.selectedItemForDelete.title = ' آیا    ' + item.title + ' حذف  شود؟ ';
//     this.selectedItemForDelete.index = i;
//     setTimeout(e => {
//       ModalUtil.showModal('modalId' + this.selectedItemForDelete.id);
//     }, 10);
//   }
//
//   deleteItem(event) {
//     if (event) {
//       this.selectedItemForDelete.loading = true;
//       this.activityService.delete({activityId: this.selectedItemForDelete.id})
//         .pipe(takeUntilDestroyed(this)).subscribe((res) => {
//         if (res === true) {
//           ModalUtil.hideModal('modalId' + this.selectedItemForDelete.id);
//           this.dataOfActivityList = this.dataOfActivityList.filter((e) => {
//             return e.id !== this.selectedItemForDelete.id;
//           });
//           DefaultNotify.notifySuccess('با موفقیت حذف شد.');
//         } else if (res !== true) {
//           ModalUtil.hideModal('modalId' + this.selectedItemForDelete.id);
//           DefaultNotify.notifyDanger(res);
//         }
//       });
//
//     } else {
//       ModalUtil.hideModal('modalId' + this.selectedItemForDelete.id);
//     }
//   }
//
//   ngOnDestroy(): void {
//   }
//
//   chooseSelectedItemForEdit(item: Activity) {
//     this.activityService.checkIfActivityIsInProcess({
//       activityId: item.id
//     }).pipe(takeUntilDestroyed(this)).subscribe((res: boolean) => {
//       if (!res) {
//         this.router.navigate(['/panel/activity/edit', item.id], {
//           // queryParams: {mode: ActionMode.EDIT, categoryId: item.id},
//           relativeTo: this.activatedRoute
//         });
//       } else if (res) {
//         DefaultNotify.notifyDanger('از این فرایند درحال حاضر استفاده می شود');
//       }
//     });
//   }
// }
//
// export class ComponentData {
//   myQuery: CourseParam.QueryParam = new CourseParam.QueryParam();
// }
//
// export namespace CourseParam {
//   export class RouteParam {
//
//   }
//
//   export class QueryParam {
//     paging: Paging;
//     term: string;
//
//     constructor() {
//       this.term = null;
//       this.paging = new Paging();
//       this.paging.page = 0;
//       this.paging.size = 10;
//     }
//   }
// }
