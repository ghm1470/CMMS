import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assigned-asset-action',
  templateUrl: './assigned-asset-action.component.html',
  styleUrls: ['./assigned-asset-action.component.scss']
})
export class AssignedAssetActionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
