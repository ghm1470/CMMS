import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assigned-work-order-view',
  templateUrl: './assigned-work-order-view.component.html',
  styleUrls: ['./assigned-work-order-view.component.scss']
})
export class AssignedWorkOrderViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
