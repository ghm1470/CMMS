export namespace Auth {
  export const RoleListKey = 'role-list'; //

}
