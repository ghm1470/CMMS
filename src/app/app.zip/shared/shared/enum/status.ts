export enum Status {
  ACTIVE = <any>'فعال',
  DE_ACTIVE = <any>'غیر فعال'

}

