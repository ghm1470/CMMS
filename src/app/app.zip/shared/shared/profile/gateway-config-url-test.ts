export const GATE_WAY_URL = 'http://185.37.55.235:8001';
