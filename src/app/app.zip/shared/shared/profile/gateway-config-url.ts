// export const GATE_WAY_URL = 'http://192.168.4.102:9060';
// export const GATE_WAY_URL = 'http://192.168.3.178:9060';
export const GATE_WAY_URL = 'http://192.168.4.253:9060';
// export const GATE_WAY_URL = 'http://192.168.4.124:9060';
// export const GATE_WAY_URL = 'http://185.37.55.235:8001';

