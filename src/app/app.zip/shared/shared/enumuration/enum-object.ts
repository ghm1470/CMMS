export class EnumObject {
    value: string;
    title: string;
}
