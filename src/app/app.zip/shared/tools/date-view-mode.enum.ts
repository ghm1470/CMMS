export enum DateViewMode {
  FULL = <any>'FULL',
  YEAR_MONTH_DAY = <any>'YEAR_MONTH_DAY',
  MONTH_AND_DAY = <any>'MONTH_AND_DAY',
  MONTH = <any>'MONTH',
  DAY = <any>'DAY',
  TIME = <any>'TIME',
}
