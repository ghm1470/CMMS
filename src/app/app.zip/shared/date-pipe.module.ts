import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    // ConvertDatePipe
  ],
  imports: [
    CommonModule,
  ],
  exports: [
    // ConvertDatePipe,
    // PersianPipesModule
  ]
})
export class DatePipeModule { }
