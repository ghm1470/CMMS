export class DeleteModel {

  id: string;
  index;
  title: string;
  loading = false;
}
