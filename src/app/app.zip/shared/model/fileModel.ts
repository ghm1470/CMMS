export class FileModel {
  id: string;
  name: string;
  type: string;
  filePath: string;
  lastModified: string;
  extraId: string;
}
