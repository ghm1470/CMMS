export enum WarrantyTimeType {
  HOURLY = <any> 'ساعت',
  DAILY = <any> 'روز',
  WEEKLY = <any> 'هفتگی',
  MONTHLY = <any> 'ماهانه',
  YEARLY = <any> 'سالانه',
}
