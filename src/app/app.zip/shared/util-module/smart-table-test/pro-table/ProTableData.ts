/**
 * Created by sina on 4/15/17.
 */
export interface ProTableData {
  headerData: string[];
  data: any[];
}
