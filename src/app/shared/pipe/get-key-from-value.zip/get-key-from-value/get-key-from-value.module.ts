import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {GetKeyFromValuePipePipe} from './GetKeyFromValue.pipe';


@NgModule({
  declarations: [GetKeyFromValuePipePipe],
  exports: [GetKeyFromValuePipePipe],
  imports: [
    CommonModule
  ]
})
export class GetKeyFromValueModule {
}
