import {Pipe, PipeTransform} from '@angular/core';
@Pipe({
  name: 'GetKeyFromValuePipe'
})
export class GetKeyFromValuePipePipe implements PipeTransform {

  constructor() {
  }

  transform(key: any, list: any[]): string {
    return convert(key);
    function convert(value: any): any {
      const item = list.find(e => e.value === value);
      return item?.key;
    }
  }
}
